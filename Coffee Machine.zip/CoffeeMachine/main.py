from collections import Counter

Order = ''
resources = Counter({'Water': 300, 'Milk': 200, 'Coffee': 100, 'Money': 0})
espresso = Counter({'Water': 50, 'Milk': 0, 'Coffee': 18, 'Money': 1.5})
latte = Counter({"Water": 200, "Milk": 150, "Coffee": 24, "Money": 2.5})
cappuccino = Counter({"Water": 250, "Milk": 100, "Coffee": 24, "Money": 3.0})
money = Counter({"quarter": 0.25, "dime": 0.10, "nickle": 0.05, "pennie": 0.01})
values = []
Cash = 0
i = 0

# for key in money:
#     Cash += money[key] * values[i]
#     i += 1

while Order != 'resources' or Order != 'espresso' or Order != 'latte' or Order != 'cappuccino':

    Order = input('What would you Like?(espresso/latte/cappuccino):')
    if Order == 'report':
        for key in resources:
            print(key, '-->', resources[key])

    elif Order == 'espresso':
        if resources['Water'] < espresso['Water']:
            print('Sorry, Water is not enough')
        elif resources['Milk'] < espresso['Milk']:
            print('Sorry, Milk is not enough')
        elif resources['Coffee'] < espresso['Coffee']:
            print('Sorry, Coffee is not enough')
        else:
            print('Please insert coins.')
            for value in money:
                if value == 'quarter':
                    m = int(input('How many quarter?:'))
                    values.append(m)
                if value == 'dime':
                    m = int(input('How many dime?'))
                    values.append(m)
                if value == 'nickle':
                    m = int(input('How many nickle?:'))
                    values.append(m)
                if value == 'pennie':
                    m = int(input('How many pennie?:'))
                    values.append(m)
            for key in money:
                Cash += money[key] * values[i]
                i += 1
            if Cash > espresso['Money']:
                for key in resources and espresso:
                    if key == 'Money':
                        xes = resources[key] + espresso[key]
                        resources[key] = xes
                    else:
                        ses = resources[key] - espresso[key]
                        resources[key] = ses
                change = Cash - espresso['Money']
                print('Here is ' + str(float(round(change))) + ' in change ')
                print('Here is your espresso enjoy!')
            elif Cash == espresso['Money']:
                for key in resources and espresso:
                    if key == 'Money':
                        xes = resources[key] + espresso[key]
                        resources[key] = xes
                    else:
                        ses = resources[key] - espresso[key]
                        resources[key] = ses
                print('Here is your espresso enjoy!')
            elif Cash < espresso['Money']:
                print("Sorry, your money is not enough !... hold on; we're refunding you now")

    elif Order == 'latte':
        if resources['Water'] < latte['Water']:
            print('Sorry, Water is not enough')
        elif resources['Milk'] < latte['Milk']:
            print('Sorry, Milk is not enough')
        elif resources['Coffee'] < latte['Coffee']:
            print('Sorry, Coffee is not enough')
        else:
            print('Please insert coins.')
            for value in money:
                if value == 'quarter':
                    m = int(input('How many quarter?:'))
                    values.append(m)
                if value == 'dime':
                    m = int(input('How many dime?'))
                    values.append(m)
                if value == 'nickle':
                    m = int(input('How many nickle?'))
                    values.append(m)
                if value == 'pennie':
                    m = int(input('How many pennie?'))
                    values.append(m)
            for key in money:
                Cash += money[key] * values[i]
                i += 1
            if Cash > latte['Money']:
                for key in resources and latte:
                    if key == 'Money':
                        xes = resources[key] + latte[key]
                        resources[key] = xes
                    else:
                        ses = resources[key] - latte[key]
                        resources[key] = ses
                change = Cash - latte['Money']
                print('Here is ' + str(float(round(change))) + ' in change')
                print('Here is your latte enjoy!')
            elif Cash == latte['Money']:
                for key in resources and latte:
                    if key == 'Money':
                        xes = resources[key] + latte[key]
                        resources[key] = xes
                    else:
                        ses = resources[key] - latte[key]
                        resources[key] = ses
                print('Here is your latte enjoy!')
            elif Cash < latte['Money']:
                print("Sorry, that's not enough money!... hold on; we're refunding you now!")

    elif Order == 'cappuccino':
        if resources['Water'] < cappuccino['Water']:
            print('Sorry, Water is not enough')
        elif resources['Milk'] < cappuccino['Milk']:
            print('Sorry, Milk is not enough')
        elif resources['Coffee'] < cappuccino['Coffee']:
            print('Sorry, Coffee is not enough')
        else:
            print('Please insert coins.')
            for value in money:
                if value == 'quarter':
                    m = int(input('How many quarter?:'))
                    values.append(m)
                if value == 'dime':
                    m = int(input('How many dime?'))
                    values.append(m)
                if value == 'nickle':
                    m = int(input('How many nickle?'))
                    values.append(m)
                if value == 'pennie':
                    m = int(input('How many pennie?'))
                    values.append(m)
            for key in money:
                Cash += money[key] * values[i]
                i += 1
            if Cash > cappuccino['Money']:
                for key in resources and cappuccino:
                    if key == 'Money':
                        xes = resources[key] + cappuccino[key]
                        resources[key] = xes
                    else:
                        ses = resources[key] - cappuccino[key]
                        resources[key] = ses
                change = Cash - cappuccino['Money']
                print('Here is ' + str(float(round(change))) + ' in change')
                print('Here is your cappuccino enjoy!')
            elif Cash == cappuccino['Money']:
                for key in resources and cappuccino:
                    if key == 'Money':
                        xes = resources[key] + cappuccino[key]
                        resources[key] = xes
                    else:
                        ses = resources[key] - cappuccino[key]
                        resources[key] = ses
                print('Here is your Cappuccino enjoy!')
            elif Cash < resources['Money']:
                print("Sorry, that's not enough money!... hold on; we're refunding you now!")

    else:
        if Order == 'off':
            Order = quit()
