from tkinter import *
from PIL import Image, ImageTk
from tkinter import messagebox
from plyer import notification
import time

t = Tk()
t.title("Notification-App")
t.geometry('500x300')
img = Image.open('myimage.png')
tkimage = ImageTk.PhotoImage(img)

def details():
    get_title = entry1.get()
    get_msg = entry2.get()
    get_time = entry3.get()

    if get_title == ""  or get_msg == "" or get_time == "":
        messagebox.showerror("Alert!", "All fields are required!")
    else:
        int_time = int(float(get_time))
        min_to_sec = int_time * 60
        messagebox.showinfo('notifier set', 'Set Notification?')
        t.destroy()
        time.sleep(min_to_sec)

        notification.notify(title = get_title,
                            message = get_msg,
                            app_name = 'notifier',
                            app_icon = "ico.ico",
                            timeout = 10
                            )

image = Label(t, image=tkimage).grid()

label1 = Label(t, text="Notifier: App for Desktop", font=("Poppins", 15, 'bold'))
label1.place(x=130, y=10)

label2 = Label(t, text="Title of Notification", font=("poppins",10))
label2.place(x=20, y=70)
entry1= Entry(t, width="25", font=("poppins",10))
entry1.place(x=145, y=70)

label3 = Label(t, text="Display Message", font=("poppins", 10))
label3.place(x=20, y=120)
entry2 =Entry(t, width="30",font=("poppins",10))
entry2.place(x=145, y=120)

label4 = Label(t, text="Set Time", font=("poppins",10))
label4.place(x=20, y=170)
entry3 = Entry(t, width="25", font=("poppins",10))
entry3.place(x=145, y=170)

but=Button(t,text="SET NOTIFICATION",font=('poppins',10,'bold', ),fg='#FFFFFF',bg='#800000',width='20',relief='raised',command=details)
but.place(x=170, y=230)

t.resizable(0,0)
t.mainloop()